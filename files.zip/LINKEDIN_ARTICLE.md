_Paste into LinkedIn's "Write article" editor (the article feature, not a normal post). Replace the repo link at the end with your URL. The post tells people the finding; this tells them how I got it._

# How I tested whether gold is really a geopolitical hedge — method, code, and the dead end that got me there

If you read the post, you know the finding: gold reacts to geopolitical shocks no more than it does to a routine Fed meeting. This is the how. I'll walk through the data, the method, the hypothesis that died on the way, and the regression — in plain English first, with a technical appendix at the end for anyone who wants the specification and the table.

## Where this started (and why the first version was wrong)

I didn't set out to study geopolitics. I trade gold, and I'd noticed it seemed to move violently on Fed days lately. So the first question was political: does gold react to FOMC decisions differently depending on who's in the White House? I tagged every Fed meeting from 2015 to 2026 across four administrations and measured gold's move around each one.

The first cut looked promising — gold's Fed-day reaction was visibly larger in the most recent stretch. That's exactly the kind of tidy result that's tempting to publish and dangerous to trust, because the recent stretch contains something else: a war. Gold is a safe-haven asset, and the Iran–Israel–US conflict ran through the same meetings I was crediting to the administration. Political effect or geopolitical effect? They were tangled in the same dates.

So I tried to break my own result, two ways. First, I added a control flag for whether each meeting fell during active conflict; the "administration effect" lost significance once the war flag was in the model — the war was doing the work. Second, a placebo test: I compared Fed-day moves to ordinary-day moves *within* the same recent period. If the Fed were genuinely special, Fed days would stand out against their own neighbours. They didn't. Gold was elevated on every day because of the war, and Fed days just inherited that.

The political hypothesis was dead. But it died in an interesting direction — if geopolitical risk could swamp a presidential effect, then the real question was the one everyone assumes they already know: **how much does gold actually move around geopolitical shocks?**

## The data

- **Gold:** daily XAU/USD (OANDA, exported from TradingView), January 2015 to June 2026 — roughly 3,000 trading days.
- **Fed meetings:** all 93 FOMC announcement dates over the period, from the Federal Reserve's own calendar.
- **Geopolitical shocks:** 15 dateable, market-moving events — Brexit, the Soleimani killing, Russia's invasion of Ukraine, the Israel–Hamas war, both Iran wars, the Abqaiq oil attack, and others.

## The method, in plain terms

This is an **event study** — a standard tool for asking "did something specific move the price." The logic is simple: pick the event date, draw a short window around it, and measure how much the asset moved versus how much it moves normally.

For each event I took a window of two trading days either side of the announcement (a "±2-day window") and measured gold's cumulative move across it. Two days because that's long enough to capture the reaction plus any next-day follow-through, but short enough that you're not sweeping in unrelated noise. I used log returns rather than simple percentage changes — a small technical choice that matters because log returns add up cleanly across a window, which is what makes event-study math work.

Then I did the obvious comparison: the average size of gold's move around the 15 geopolitical shocks, against the average around the 93 Fed meetings, against an ordinary trading day as a baseline.

## What the comparison showed

- **Ordinary trading day:** gold moves about 0.7% on average.
- **Fed meeting (±2-day window):** about 1.9%.
- **Geopolitical shock (±2-day window):** about 1.5%.

So geopolitical shocks move gold *less*, on average, than Fed meetings — the reverse of the cliché. But "less on average" isn't a claim you can make until you've checked whether the gap is real or just noise, which is what the regression is for (appendix below). It isn't: the difference is not statistically significant. The honest, defensible version is the **null** — geopolitical shocks move gold *no more* than the Fed does.

Two patterns made it sharper. The biggest single mover in the entire sample was Brexit (+4%), not any war — the shocks that moved gold were *surprises* and *financial-systemic* events, not telegraphed military escalation. And splitting the shocks by period, gold's reaction has been *shrinking*: roughly 1.7% in 2015–19, 2.0% in 2020–22, but only 0.9% in 2023–26. That cuts against the popular idea that we're in a "structural geopolitical supercycle" for gold.

## What I'd want a critic to hit

The sample is 15 shocks, and Brexit is a big outlier — that's exactly why the standard errors are wide and the difference comes out insignificant. Dating a "shock" to one day is a judgment call; I used unambiguous, widely-reported dates and pinned multi-day events to their onset, but someone could reasonably date them differently. And daily data can't see intraday or single-headline moves — if gold spikes and round-trips within a day, my window understates it. None of these kill the finding, but they bound it, and pretending otherwise would be the dishonest move.

## Why I kept the dead end in

I could have cut the Trump section and shown a clean result. I left it because the actual sequence — hypothesis, apparent support, suspicion, a confound that breaks it, a pivot to a better question — is what empirical work actually is. The null I ended on is less exciting than the headline I started with. It's also what the data supports, and I'd rather post that.

---

## Technical appendix

**Return construction.** Daily log return r_t = ln(P_t / P_{t-1}) on close prices. Window move for an event at reaction-day index i is the cumulative log return from the close at i−3 to the close at i+2 (a symmetric ±2 trading-day window around the reaction day), expressed in percent.

**Event counts.** FOMC: n = 93. Geopolitical shocks: n = 15. Baseline = mean absolute daily log return over all ~3,000 days (0.70%).

**Descriptive results (mean |±2-day window move|).**

| Event type | n | Mean abs. move |
|---|---|---|
| Ordinary day | ~3,000 | 0.70% |
| FOMC meeting | 93 | 1.88% |
| Geopolitical shock | 15 | 1.47% |

Geopolitical shocks with gold up over the window: 67%. Period split of shock reactions: 2015–19 ≈ 1.74% (n=5), 2020–22 ≈ 2.02% (n=4), 2023–26 ≈ 0.87% (n=6).

**Formal test.** Pool all 108 events; regress the absolute window move (in percentage points) on a dummy `geo` = 1 for geopolitical shocks, 0 for FOMC. HC1 heteroskedasticity-robust standard errors (event types have different variances, so classical SEs would be miscalibrated).

```
                Estimate   Std. Error   t value   Pr(>|t|)
(Intercept)      1.8840       0.2038      9.247    2.8e-15  ***
geo             -0.4157       0.3647     -1.140      0.257
```

Intercept (1.88) = mean FOMC window move. The `geo` coefficient (−0.42) is the average difference for a geopolitical shock — directionally smaller, but p = 0.26, so not distinguishable from zero. The data cannot reject "geopolitical shocks move gold the same amount as Fed meetings." This is the basis for stating the result as a null rather than as "geopolitics moves gold less."

**Confound check (the abandoned hypothesis).** Splitting the 12 most-recent-administration FOMC meetings into those inside vs outside an active-conflict window gave mean window moves of 4.9% (n=4, war) vs 2.5% (n=8, calm). Adding a war dummy to a regression of the window move on an administration dummy drove the administration coefficient from significant (p≈0.05) to insignificant (p≈0.12). A placebo test — ratio of mean |FOMC-day move| to mean |ordinary-day move| within each administration — put the recent administration at 1.12×, the *lowest* of the four, indicating its Fed days were not unusually reactive once the elevated wartime baseline is accounted for.

**Reproducibility.** Single R script (base R + ggplot2 + sandwich + lmtest), reads the raw TradingView CSV, builds the windows, prints the tables, runs the regression, and renders the chart. Repo: _[link]_

**Limitations.** n = 15 shocks; Brexit is a high-leverage outlier; shock dating is judgment-based; daily frequency misses intraday dynamics; the geopolitical-shock set is hand-selected, not drawn from a formal index like the GPR.
