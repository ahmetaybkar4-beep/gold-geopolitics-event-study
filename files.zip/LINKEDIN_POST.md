_This is the short FEED POST — a normal LinkedIn update. Attach the chart image. Put the article link in the FIRST COMMENT, not the post body (LinkedIn suppresses reach on posts with external links in the body)._

---

Everyone calls gold the ultimate geopolitical hedge.

I pulled 11 years of daily prices and tested it against 15 major shocks since 2015 — Brexit, Soleimani, Ukraine, both Iran wars.

Gold reacted no more to those shocks than it does to an ordinary Fed meeting. 1.5% vs 1.9% over a two-day window — and the difference isn't statistically significant (p = 0.26).

Three things stood out:

→ The biggest mover wasn't a war. It was Brexit (+4%). Gold reacts to surprises, not to scary headlines it already saw coming.

→ By the time the missiles actually fly, the move is mostly priced in.

→ Gold's sensitivity to geopolitical shocks has been shrinking over the decade — the opposite of the "supercycle" story everyone's selling.

It started as a different question entirely — whether gold reacts to the Fed differently depending on who's president. That hypothesis died when I found a confound I couldn't rule out, and chasing it led here.

Full method, the regression, and the reproducible R code in the article below. Tell me what I'm missing.
